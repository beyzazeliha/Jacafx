import java.io.File;
import java.io.FileInputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Map;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.StackedBarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class CountryView extends Application {

    private static Scene MainScene;
    private static boolean CountryChartDataType = true;//true for cases, false for deaths
    private static String ContDataType;


    public static void LoadView(){
        launch();
    }
    public static void ActivateBarChart(){

        Button ShowContinentData = (Button) MainScene.lookup("#ContButton");
        ComboBox<String> GraphType = (ComboBox<String>) MainScene.lookup("#ContType");
        GraphType.getItems().addAll("Cases","Deaths");
        ShowContinentData.setOnAction(new EventHandler<ActionEvent>(){
        
            @Override
            public void handle(ActionEvent arg0) {
                CallController.CallControllerFınc("ShowContinentData");
                ContDataType = GraphType.getValue().toString();
            }
        });
    }

    public static void ShowCountryList(ArrayList<String> CoountryList) {
        ListView<String> Countries = (ListView<String>) MainScene.lookup("#CountryList");//Get the Listview for countries
        Countries.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);//Set selection mode
        Countries.getItems().addAll(CoountryList);//Set Data

        //Radio grup for selecting data type
        RadioButton Cases = (RadioButton) MainScene.lookup("#Cases");
        RadioButton Deaths = (RadioButton) MainScene.lookup("#Deaths");
        Cases.setOnAction(e-> CountryChartDataType = true);
        Deaths.setOnAction(e-> CountryChartDataType = false);

        //Button setting for showing data in line chart
        Button ShowCountryData = (Button)MainScene.lookup("#CountryButton");
        ShowCountryData.setOnAction(e->{
            ObservableList<String> CList = Countries.getSelectionModel().getSelectedItems();
            ArrayList<String> NameList = new ArrayList<>();
            for (String CountryName : CList) {
                NameList.add(CountryName);
            }
            CallController.CallControllerFınc("ShowCountryDataOnChart",NameList);
        });
    }
    @Override
    public void start(Stage MainStage) throws Exception {

        File GUIFile = new File(getClass().getResource("CovidFX.fxml").getFile());
        FileInputStream GUIFileStream = new FileInputStream(GUIFile);
        FXMLLoader GUIloader = new FXMLLoader();
        Pane MainPane = GUIloader.load(GUIFileStream);

        MainScene = new Scene(MainPane, 650,600);

        Button GetSourceButton = (Button) MainScene.lookup("#GetDataButton");
        GetSourceButton.setOnAction(e->GetSourceEventHandler());

        MainStage.setScene(MainScene);
        MainStage.show();

    }

    private static void GetSourceEventHandler(){//When the Get Data button is clicked
        TextField SourceField = (TextField) MainScene.lookup("#SourceField");
        CallController.CallControllerFınc("GetDataFromSource",SourceField.getText());
        CallController.CallControllerFınc("ListCountryData");
        CallController.CallControllerFınc("ShowCountryList");
        
    }

    public static void ShowCountryDataOnTable(ArrayList<Country> AllCountries){
        //Create Columns
        TableColumn<Country,String> CountryColumn = new TableColumn<>("Country");
        TableColumn<Country,Integer> NewCasesColumn = new TableColumn<>("NewCases");
        TableColumn<Country,Integer> TotalCasesColumn = new TableColumn<>("TotalCases");
        TableColumn<Country,Integer> NewDeathsColumn = new TableColumn<>("NewDeaths");
        TableColumn<Country,Integer> TotalDeathsColumn = new TableColumn<>("TotalDeaths");
        TableColumn<Country,Double> MortalityColumn = new TableColumn<>("Mortality");
        TableColumn<Country,Double> AttackRateColumn = new TableColumn<>("AttackRate");
        TableColumn<Country,Integer> PopulationColumn = new TableColumn<>("Popularion");

        //Retrieve Properties
        CountryColumn.setCellValueFactory(new PropertyValueFactory<>("Name"));
        NewCasesColumn.setCellValueFactory(new PropertyValueFactory<>("NewCases"));
        TotalCasesColumn.setCellValueFactory(new PropertyValueFactory<>("TotalCases"));
        NewDeathsColumn.setCellValueFactory(new PropertyValueFactory<>("NewDeaths"));
        TotalDeathsColumn.setCellValueFactory(new PropertyValueFactory<>("TotalDeaths"));
        MortalityColumn.setCellValueFactory(new PropertyValueFactory<>("Mortality"));
        AttackRateColumn.setCellValueFactory(new PropertyValueFactory<>("AttackRate"));
        PopulationColumn.setCellValueFactory(new PropertyValueFactory<>("Population"));

        //Get the table
        TableView<Country> CountryTable = (TableView<Country>) MainScene.lookup("#CountryTable");

        //Setting Columns to FXML columns
        CountryTable.getColumns().set(0, CountryColumn);
        CountryTable.getColumns().set(1, NewCasesColumn);
        CountryTable.getColumns().set(2, TotalCasesColumn);
        CountryTable.getColumns().set(3, NewDeathsColumn);
        CountryTable.getColumns().set(4, TotalDeathsColumn);
        CountryTable.getColumns().set(5, MortalityColumn);
        CountryTable.getColumns().set(6, AttackRateColumn);
        CountryTable.getColumns().set(7, PopulationColumn);

        //Attach Data
        ObservableList<Country> CountryTableData = FXCollections.observableArrayList(AllCountries);
        CountryTable.setItems(CountryTableData);

    }

    public static void ShowCountryDataOnLineChart(ArrayList<Country>Countries){

        LineChart<String,Integer> CountryData = (LineChart<String,Integer>) MainScene.lookup("#CountryData");
        CountryData.getData().clear();

        
        if(CountryChartDataType){
            CountryData.setTitle("Cases");
            for (Country country : Countries) {
                XYChart.Series<String,Integer> RecordSeries = new XYChart.Series<>();
                for (Record record : country.GetRecords().values()) {
                    RecordSeries.getData().add(new XYChart.Data<>(record.GetDate().toString(),record.GetCases()));
                }
                CountryData.getData().add(RecordSeries);
            }
        }else{
            CountryData.setTitle("Deaths");
            for (Country country : Countries) {
                XYChart.Series<String,Integer> RecordSeries = new XYChart.Series<>();
                for (Record record : country.GetRecords().values()) {
                    RecordSeries.getData().add(new XYChart.Data<>(record.GetDate().toString(),record.GetDeaths()));
                }
                CountryData.getData().add(RecordSeries);
            }
        }
    }

    public static void ShowContinentDataOnBarchart(Map<String,Map<LocalDate,ArrayList<Record>>>Data){

        StackedBarChart<String,Integer> ContinentDataChart = (StackedBarChart<String,Integer>) MainScene.lookup("#ContData");
        ContinentDataChart.getData().clear();

        if(ContDataType == "Cases"){
            ContinentDataChart.setTitle("Cases");
            for (Map.Entry<String,Map<LocalDate,ArrayList<Record>>> entry : Data.entrySet()) {
                XYChart.Series<String,Integer> ContData = new XYChart.Series<>();
                ContData.setName(entry.getKey());
                for (Map.Entry<LocalDate,ArrayList<Record>> subEntry : entry.getValue().entrySet()) {
                    int NumberOfData = 0;
                    for (Record Record : subEntry.getValue()) {
                        NumberOfData = NumberOfData + Record.GetCases();
                    }
                    String Date = subEntry.getKey().toString();
                    ContData.getData().add(new XYChart.Data<>(Date,NumberOfData));
                }
                ContinentDataChart.getData().add(ContData);
            }
        }else{
            ContinentDataChart.setTitle("Deaths");
            for (Map.Entry<String,Map<LocalDate,ArrayList<Record>>> entry : Data.entrySet()) {
                XYChart.Series<String,Integer> ContData = new XYChart.Series<>();
                ContData.setName(entry.getKey());
                for (Map.Entry<LocalDate,ArrayList<Record>> subEntry : entry.getValue().entrySet()) {
                    int NumberOfData = 0;
                    for (Record Record : subEntry.getValue()) {
                        NumberOfData = NumberOfData + Record.GetDeaths();
                    }
                    String Date = subEntry.getKey().toString();
                    ContData.getData().add(new XYChart.Data<>(Date,NumberOfData));
                }
                ContinentDataChart.getData().add(ContData);
            }
        }
    }
}