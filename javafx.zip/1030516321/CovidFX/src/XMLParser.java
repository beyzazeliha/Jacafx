import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class XMLParser {
    private String RecordString;
    private static String DeletionReg = "<(.*?)>|</(.*?)>";
    public XMLParser(String recordString){
        this.RecordString = recordString;
    }
    public String GetName(){
        Pattern CnamePattern = Pattern.compile("<countriesAndTerritories>(.+?)</countriesAndTerritories>");
        Matcher NameMatcher = CnamePattern.matcher(this.RecordString);
        if(NameMatcher.find()){
            String NameData =  NameMatcher.group();
            NameData = NameData.replaceAll(DeletionReg, "");
            return NameData;
        }else{
            return null; // Null for no-named Countries
        }
    }
    public String GetContinentName(){
        Pattern ContinentPattern = Pattern.compile("<continentExp>(.+?)</continentExp>");
        Matcher ContinentMatcher = ContinentPattern.matcher(this.RecordString);
        if(ContinentMatcher.find()){
            String ContinentName =  ContinentMatcher.group();
            ContinentName = ContinentName.replaceAll(DeletionReg, "");
            return ContinentName;
        }else{
            return null; // Null for not included data
        }
    }
    public int GetPopulation(){
        Pattern PopulationPattern = Pattern.compile("<popData2018>(.+?)</popData2018>");
        Matcher PopulationMatcher = PopulationPattern.matcher(this.RecordString);
        if(PopulationMatcher.find()){
            String PopulationAsString = PopulationMatcher.group().replaceAll(DeletionReg, "");
            int Population =  Integer.parseInt(PopulationAsString);
            return Population;
        }else{
            return 0; // 0 for not included data
        }
    }
    public Record getRecord(){
        //Patterns
        Pattern DatePattern = Pattern.compile("<dateRep>(.+?)</dateRep>");
        Pattern CasesPattern = Pattern.compile("<cases>(.+?)</cases>");
        Pattern DeathsPattern = Pattern.compile("<deaths>(.+?)</deaths>");

        //Matchers
        Matcher DateMatcher = DatePattern.matcher(this.RecordString);
        Matcher CasesMatcher = CasesPattern.matcher(this.RecordString);
        Matcher DeathsMatcher = DeathsPattern.matcher(this.RecordString);

        LocalDate Date;
        if(DateMatcher.find()){
            String DateAsString = DateMatcher.group().replaceAll(DeletionReg, "");
            String[] DateElements = DateAsString.split("/");
            DateAsString = DateElements[2] + "-" + DateElements[1]+"-"+DateElements[0];
            Date =  LocalDate.parse(DateAsString);
        }else{
            Date = null; // 0 for not included data
        }
        int Cases;
        if(CasesMatcher.find()){
            String CasesAsString = CasesMatcher.group().replaceAll(DeletionReg, "");
             Cases =  Integer.parseInt(CasesAsString);
        }else{
            Cases = 0; // 0 for not included data
        }
        int Deaths;
        if(DeathsMatcher.find()){
            String DeathsAsString = DeathsMatcher.group().replaceAll(DeletionReg, "");
             Deaths =  Integer.parseInt(DeathsAsString);
        }else{
            Deaths = 0; // 0 for not included data
        }
        return new Record(Date,Deaths,Cases);
    }
}