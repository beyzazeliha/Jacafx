import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class DataContext {
    private ArrayList<String>Records;
    private Map<String,Country> Context = new HashMap<>();
    private Map<String,ArrayList<Record>> ContRecords = new HashMap<>();
    public void GetContextData(String Source){
        Records = DataExctractor.GetData(Source);
    }

    public void CreateContext(){
        for (String Record : Records) {
            XMLParser RecordFromXML = new XMLParser(Record);
            AddToCountries(RecordFromXML);
            AddToContinents(RecordFromXML);
        }
    }
    private void AddToCountries(XMLParser RecordFromXML){
        if(Context.keySet().contains(RecordFromXML.GetName())){
            Country Country = Context.get(RecordFromXML.GetName());
            Country.AddtoRecords(RecordFromXML.getRecord());
        }else{
            Country Country = new Country();
            Country.setName(RecordFromXML.GetName());
            Country.setContinent(RecordFromXML.GetContinentName());
            Country.setPopulation(RecordFromXML.GetPopulation());
            Country.AddtoRecords(RecordFromXML.getRecord());
            Context.put(Country.getName(), Country);
        }
    }
    private void AddToContinents(XMLParser RecordFromXML){
        if(ContRecords.keySet().contains(RecordFromXML.GetContinentName())){
            String ContName = RecordFromXML.GetContinentName();
            ContRecords.get(ContName).add(RecordFromXML.getRecord());
        }else{
             ContRecords.put(RecordFromXML.GetContinentName(), new ArrayList<Record>(Arrays.asList(RecordFromXML.getRecord())));
        }
    }

    public Map<String,Country> GetContext(){
        return Context;
    }
    public Map<String,ArrayList<Record>> GetContContext(){
        return ContRecords;
    }
}