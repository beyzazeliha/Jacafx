import java.util.ArrayList;

public class CountryController {

    public static void StartApplication(){
        CountryView.LoadView();
    }
    public static void GetDataFromSource(String Source){
        Country.GetRecordsFromSource(Source);
        CountryView.ActivateBarChart();
    }
    public static  void ShowCountryList(){
        CountryView.ShowCountryList(Country.GetAllCountryNames());
    }
    public static void ShowDataOnLineChart(ArrayList<String> NameList){
        CountryView.ShowCountryDataOnLineChart(Country.GetCountries(NameList));
    }
    public static void ShowCountryTable(){
        CountryView.ShowCountryDataOnTable(Country.GetAllCountryData());
    }
    public static void ShowContinentData(){
        CountryView.ShowContinentDataOnBarchart(Country.GetContData());
    }
}