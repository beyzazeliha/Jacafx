import java.util.ArrayList;

public class CallController {
    public static void CallControllerFınc(String FunctionName,String Parameter){
        switch (FunctionName) {
            case "GetDataFromSource":
                CountryController.GetDataFromSource(Parameter);
                break;
            default:
                break;
        }
    }
    public static void CallControllerFınc(String FunctionName){
        if(FunctionName == "Start"){
            CountryController.StartApplication();
        }
        if(FunctionName == "ListCountryData"){
            CountryController.ShowCountryTable();
        }
        if(FunctionName == "ShowCountryList"){
            CountryController.ShowCountryList();
        }
        if(FunctionName == "ShowContinentData"){
            CountryController.ShowContinentData();;
        }
    }
    public static void CallControllerFınc(String FunctionName,ArrayList<String>Parameter){
        if(FunctionName == "ShowCountryDataOnChart"){
            CountryController.ShowDataOnLineChart(Parameter);
        }
    }
}