import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataExctractor {
    public static ArrayList<String>GetData(String DataSource){
        String WebPattern = "(http|https)://(\\w+\\.)+(edu|com|gov|eu|org)(.*?)";
        String FilePattern = "";
        ArrayList<String> Records = null;
        if(DataSource.matches(WebPattern)){
            Records = FromWeb(DataSource);
        }else if(DataSource.matches(FilePattern)){
            Records = FromFile(DataSource);
        }
        return Records;
    }
    private static ArrayList<String>FromWeb(String Source){
        Pattern RecordPattern = Pattern.compile("<record>(.*?)</record>");
        Matcher RecordMatcher;
        ArrayList<String> Recordlist = new ArrayList<String>();
        try {
            URL SourceURL = new URL(Source);
            Scanner Scanner = new Scanner(SourceURL.openStream());
            String RecordString = "";
            while(Scanner.hasNext()){
                String Line = Scanner.nextLine().trim();
                RecordString = RecordString + Line;
                RecordMatcher = RecordPattern.matcher(RecordString);
                if(RecordMatcher.find()){
                    Recordlist.add(RecordMatcher.group());
                    RecordString = "";
                }
            }
            Scanner.close();
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return Recordlist;
    }
    private static ArrayList<String>FromFile(String Source){
        Pattern RecordPattern = Pattern.compile("<record>(.*?)</record>");
        Matcher RecordMatcher;
        ArrayList<String> Recordlist = new ArrayList<String>();
        try {
            File SourceFile = new File(Source);
            FileInputStream SourceStream = new FileInputStream(SourceFile);
            Scanner Scanner = new Scanner(SourceStream);
            String RecordString = "";
            while(Scanner.hasNext()){
                String Line = Scanner.nextLine().trim();
                RecordString = RecordString + Line;
                RecordMatcher = RecordPattern.matcher(RecordString);
                if(RecordMatcher.find()){
                    Recordlist.add(RecordMatcher.group());
                    RecordString = "";
                }
            }
            Scanner.close();
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        
        return Recordlist;
    }
}