import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Country {
    //Property variables
    private String Name;
    private String Continent;
    private int Population;
    private Map<LocalDate,Record> Records = new HashMap<>();

    //DataContext for Querrying
    private static DataContext dataContext;

    //Static methods for querrying
    public static void GetRecordsFromSource(String Source){
        dataContext = new DataContext();
        dataContext.GetContextData(Source);
        dataContext.CreateContext();
    }
    
    public static ArrayList<String> GetAllCountryNames(){
        ArrayList<String> CountryList = new ArrayList<String>();
        for (String CName : dataContext.GetContext().keySet()) {
            CountryList.add(CName);
        }
        return CountryList;
    }

    public static ArrayList<Country> GetCountries(ArrayList<String>NameList){
        ArrayList<Country> Countries = new ArrayList<>();
        for (String name : NameList) {
            Countries.add(GetCountry(name));
        }
        return Countries;
    }
    
    public static Country GetCountry(String Name){
        return dataContext.GetContext().get(Name);
    }
    public static ArrayList<Country> GetAllCountryData(){
        ArrayList<Country> AllCountries = new ArrayList<>();
        for (Country country : dataContext.GetContext().values()) {
            AllCountries.add(country);
        }
        return AllCountries;
    }
    public static Map<String,Map<LocalDate,ArrayList<Record>>> GetContData(){
        Map<String,Map<LocalDate,ArrayList<Record>>> ContData = new HashMap<>();
        for (Map.Entry<String,ArrayList<Record>> Entry : dataContext.GetContContext().entrySet()) {
            Map<LocalDate,ArrayList<Record>> RecsByDate = new HashMap<>();
            for (Record record : Entry.getValue()) {
                if(RecsByDate.keySet().contains(record.GetDate())){
                    RecsByDate.get(record.GetDate()).add(record);
                }else{
                    RecsByDate.put(record.GetDate(), new ArrayList<Record>(Arrays.asList(record)));
                }
            }
            ContData.put(Entry.getKey(), RecsByDate);
        }
        return ContData;
    }
    //Getter Methods
    public Map<LocalDate,Record> GetRecords(){
        return Records;
    }
    public String getName(){
        return Name;
    }
    public String getContinent(){
        return this.Continent;
    }
    public int getTotalCases(){
        int TotalCases = 0;
        for (Record record : this.Records.values()) {
            TotalCases = TotalCases + record.GetCases();
        }
        return TotalCases;
    }
    public int getNewCases(){
        LocalDate Yesterday = LocalDate.now().minusDays(1);
        return this.Records.get(Yesterday).GetCases();
    }
    public int getTotalDeaths(){
        int TotalDeaths = 0;
        for (Record record : this.Records.values()) {
            TotalDeaths = TotalDeaths + record.GetDeaths();
        }
        return TotalDeaths;
    }
    public int getNewDeaths(){
        LocalDate Yesterday = LocalDate.now().minusDays(1);
        return this.Records.get(Yesterday).GetDeaths();
    }
    public int getPopulation(){
        return Population;
    }
    public double getMortality(){
        double Mortality = (double)  this.getTotalDeaths()/this.getTotalCases();
        return Mortality;
    }
    public double getAttackRate(){
        double AttackRate = (double) this.getTotalCases()/this.Population;
        return AttackRate;
    }
    //Setter methods
    public void AddtoRecords(Record record){
        this.Records.put(record.GetDate(), record);
    }
    public void setName(String Name){
        this.Name = Name;
    }
    public void setContinent(String Continent){
        this.Continent = Continent;
    }
    public void setPopulation(int Population){
        this.Population = Population;
    }
}