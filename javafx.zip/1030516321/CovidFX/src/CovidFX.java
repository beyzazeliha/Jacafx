public class CovidFX {
    public static void main(String[] args) throws Exception {
        CallController.CallControllerFınc("Start");
    }
}
