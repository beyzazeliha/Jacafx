import java.time.LocalDate;
public class Record {
    private LocalDate Date;
    private int Deaths;
    private int Cases;

    public Record(LocalDate Date, int Deaths,int Cases){
        this.Date = Date;
        this.Cases = Cases;
        this.Deaths = Deaths;
    }
    public LocalDate GetDate(){
        return this.Date;
    }
    public int GetCases(){
        return this.Cases;
    }
    public int GetDeaths(){
        return this.Deaths;
    }
}